<?php
const DB_HOST_NAME = 'localhost';
const DB_USER_NAME = 'root';
const DB_PASS = '';
const DB_NAME = 'crudoperation_lab';


const TBL_USERS = 'users';
