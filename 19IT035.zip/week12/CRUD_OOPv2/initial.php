<?php

$database = new Database();
$db = $database->getConnection();