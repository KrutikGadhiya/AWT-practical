<?php
// used to connect to the database
const DB_HOST = "localhost";
const DB_NAME = "crud_oop";
const DB_USERNAME = "root";
const DB_PASSWORD = "";
const DB_CONNECTION = "";
const DB_TABLE_USER = "users";


const MSG_SUCCESS = "Operation Performed Successfully. ";
const MSG_FAILURE = "Oops, Operation Fail. ";
