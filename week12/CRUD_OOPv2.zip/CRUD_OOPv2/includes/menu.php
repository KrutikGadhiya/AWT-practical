<div class="row">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary m-2 ">
        <div class="container-fluid">
            <a class="navbar-brand" href="./index.php">Demo CRUD - OOP</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse d-flex justify-content-end " id="navbarNavAltMarkup">
                <!-- ml-auto still works just fine-->
                <div class="navbar-nav ml-auto">
                    <a class="nav-link" aria-current="page" href="index.php">Users List</a>
                </div>
            </div>
        </div>
    </nav>

</div>