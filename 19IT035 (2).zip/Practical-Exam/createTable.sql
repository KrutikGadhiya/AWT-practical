create table student(
  srno int(11) PRIMARY KEY AUTO_INCREMENT,
  fullname varchar(150) NOT NULL,
  sub varchar(150) NOT NULL,
  department varchar(150) NOT NULL,
  cgpa int(11) NOT NULL
);